"""Base model for event processing results using Pydantic."""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field


class ProcessingResult(BaseModel):
    model_config = ConfigDict(frozen=False, arbitrary_types_allowed=True)

    is_success: bool = Field(default=True, description="Indicates successful execution")
    event_type: str = Field(default="UNKNOWN", description="Domain classification of event")
    error_message: str | None = Field(default=None, description="Details on processing error")
