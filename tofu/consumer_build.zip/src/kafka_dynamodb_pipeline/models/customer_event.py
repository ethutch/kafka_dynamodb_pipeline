"""Customer domain model and Protobuf deserializer."""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

from pydantic import Field, field_validator

from kafka_dynamodb_pipeline.config.settings import get_settings
from kafka_dynamodb_pipeline.models.processing_result import ProcessingResult
from kafka_dynamodb_pipeline.proto.customer_event_pb2 import CustomerEventMessage


class CustomerEvent(ProcessingResult):
    event_type: str = Field(default="CUSTOMER")

    correlation_id: str = ""
    action: str = ""
    customer_id: str = ""
    company_name: str = ""
    contact_name: str | None = None
    contact_title: str | None = None
    address: str | None = None
    city: str | None = None
    region: str | None = None
    postal_code: str | None = None
    country: str | None = None
    phone: str | None = None
    fax: str | None = None
    created_by: str | None = None
    updated_by: str | None = None
    created_at: datetime | None = None
    updated_at: datetime | None = None

    @field_validator("action")
    @classmethod
    def validate_action(cls, v: str) -> str:
        s = v.strip().upper()
        if not s:
            raise ValueError("action cannot be empty")

        settings = get_settings()
        supported = settings.supported_customer_events
        if supported and s not in supported:
            raise ValueError(f"Unsupported event action '{s}'. Supported actions: {supported}")

        return s

    @field_validator("customer_id")
    @classmethod
    def validate_customer_id(cls, v: str) -> str:
        s = v.strip()
        if not s:
            raise ValueError("customer_id cannot be empty")
        return s[:5]

    @classmethod
    def from_proto(cls, pb_msg: CustomerEventMessage) -> CustomerEvent:
        created_at = (
            datetime.fromtimestamp(pb_msg.created_at.seconds, tz=UTC)
            if pb_msg.HasField("created_at")
            else None
        )
        updated_at = (
            datetime.fromtimestamp(pb_msg.updated_at.seconds, tz=UTC)
            if pb_msg.HasField("updated_at")
            else None
        )

        return cls(
            correlation_id=pb_msg.correlation_id,
            action=pb_msg.action,
            customer_id=pb_msg.customer_id,
            company_name=pb_msg.company_name[:40] if pb_msg.company_name else "",
            contact_name=pb_msg.contact_name[:30] if pb_msg.contact_name else None,
            contact_title=pb_msg.contact_title[:30] if pb_msg.contact_title else None,
            address=pb_msg.address[:60] if pb_msg.address else None,
            city=pb_msg.city[:15] if pb_msg.city else None,
            region=pb_msg.region[:15] if pb_msg.region else None,
            postal_code=pb_msg.postal_code[:10] if pb_msg.postal_code else None,
            country=pb_msg.country[:15] if pb_msg.country else None,
            phone=pb_phone[:24] if (pb_phone := pb_msg.phone) else None,
            fax=pb_msg.fax[:24] if pb_msg.fax else None,
            created_by=pb_msg.created_by or None,
            updated_by=pb_msg.updated_by or None,
            created_at=created_at,
            updated_at=updated_at,
        )

    def to_dynamodb_item(self) -> dict[str, Any]:
        """Convert validated model into DynamoDB item dictionary, dropping empty fields."""
        dump = self.model_dump(exclude={"is_success", "event_type", "error_message"}, mode="json")
        return {k: v for k, v in dump.items() if v is not None and v != ""}
