"""Application configuration — loaded from environment variables / .env file."""

from __future__ import annotations

from functools import lru_cache
from typing import Annotated, Any, Literal

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, NoDecode, SettingsConfigDict


class DynamoDBSettings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="DYNAMODB_", env_file=".env", extra="ignore")

    endpoint_url: str | None = Field(
        default=None, description="Custom endpoint for local DynamoDB container"
    )
    table_name: str = Field(default="customers", description="Target DynamoDB table name")
    region_name: str = Field(default="us-east-1", description="AWS Region")


class KafkaSettings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="KAFKA_", env_file=".env", extra="ignore")

    bootstrap_servers: str = Field(default="kafka:9092", description="Kafka broker endpoints")
    topics: Annotated[list[str], NoDecode] = Field(
        default=["customer-events"], description="Kafka topics list"
    )

    @field_validator("topics", mode="before")
    @classmethod
    def decode_list(cls, v: Any) -> list[str]:
        if isinstance(v, str):
            return [x.strip() for x in v.split(",") if x.strip()]
        if isinstance(v, (list, tuple, set)):
            return [str(x).strip() for x in v if str(x).strip()]
        return []


class AppSettings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    log_level: Literal["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"] = "INFO"
    environment: str = Field(default="local", description="Runtime environment")
    batch_size: int = Field(default=100, description="Max batch size")
    batch_timeout_ms: int = Field(default=5000, description="Max batch timeout in ms")

    supported_customer_events: Annotated[set[str], NoDecode] = Field(
        default_factory=lambda: {"CREATE", "UPDATE", "DELETE"},
        description="Supported customer event action types",
    )

    dynamodb: DynamoDBSettings = Field(default_factory=DynamoDBSettings)
    kafka: KafkaSettings = Field(default_factory=KafkaSettings)

    @field_validator("supported_customer_events", mode="before")
    @classmethod
    def decode_supported_events(cls, v: Any) -> set[str]:
        if isinstance(v, str):
            return {x.strip().upper() for x in v.split(",") if x.strip()}
        if isinstance(v, (list, tuple, set)):
            return {str(x).strip().upper() for x in v if str(x).strip()}
        return set()


@lru_cache(maxsize=1)
def get_settings() -> AppSettings:
    """Return a cached singleton of AppSettings."""
    return AppSettings()
