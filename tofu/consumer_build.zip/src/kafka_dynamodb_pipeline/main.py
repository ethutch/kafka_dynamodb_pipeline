"""Lambda consumer entrypoint for Kafka event processing."""

from __future__ import annotations

import base64
from typing import TYPE_CHECKING, Any

import boto3
from google.protobuf.message import DecodeError
from pydantic import ValidationError

from kafka_dynamodb_pipeline.config.settings import get_settings
from kafka_dynamodb_pipeline.models.customer_event import CustomerEvent
from kafka_dynamodb_pipeline.models.processing_result import ProcessingResult
from kafka_dynamodb_pipeline.proto.customer_event_pb2 import CustomerEventMessage
from kafka_dynamodb_pipeline.utils.logging import configure_logging, get_logger

if TYPE_CHECKING:
    from mypy_boto3_dynamodb.service_resource import DynamoDBServiceResource, Table

configure_logging()
log = get_logger(__name__)


def get_dynamodb_table() -> Table:
    settings = get_settings()
    dynamodb_kwargs: dict[str, Any] = {"region_name": settings.dynamodb.region_name}
    if settings.dynamodb.endpoint_url:
        dynamodb_kwargs["endpoint_url"] = settings.dynamodb.endpoint_url

    dynamodb: DynamoDBServiceResource = boto3.resource("dynamodb", **dynamodb_kwargs)
    return dynamodb.Table(settings.dynamodb.table_name)


def handler(event: dict[str, Any], context: Any) -> dict[str, Any]:  # type: ignore
    records_dict = event.get("records", {})

    processed_count = 0
    error_count = 0
    table = get_dynamodb_table()

    for partition_key, record_list in records_dict.items():
        log.info("partition.processing_started", partition=partition_key, count=len(record_list))
        for record in record_list:
            try:
                raw_bytes = base64.b64decode(record["value"])

                pb_msg = CustomerEventMessage()
                pb_msg.ParseFromString(raw_bytes)

                domain_event = CustomerEvent.from_proto(pb_msg)

                item = domain_event.to_dynamodb_item()
                table.put_item(Item=item)
                processed_count += 1

            except (DecodeError, ValidationError) as err:
                failed_res = ProcessingResult(is_success=False, error_message=str(err))
                log.error("record.deserialization_failed", error=failed_res.error_message)
                error_count += 1
            except Exception as ex:
                log.critical("record.persistence_failed", error=str(ex), exc_info=True)
                error_count += 1

    return {
        "statusCode": 200,
        "body": {
            "message": "Processed Kafka batch",
            "processed": processed_count,
            "errors": error_count,
        },
    }
