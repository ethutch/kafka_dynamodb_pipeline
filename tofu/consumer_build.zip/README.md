# Kafka → DynamoDB Event Pipeline

An enterprise-grade, event-driven Python pipeline that consumes Protobuf-serialized messages from Apache Kafka, deserializes and validates events using Pydantic models, and persists records to Amazon DynamoDB via AWS Lambda and LocalStack.

---

## Architecture Overview

+-----------------------------------------------------------------------------------+
| Host Machine / Docker Network                                                     |
|                                                                                   |
|  +--------------------+         +-----------------------+                         |
|  | Kafka Container    | <====== | LocalStack Container  |                         |
|  | (Port 9092)        | Poller  | (Port 4566)           |                         |
|  +--------------------+         |                       |                         |
|            |                    |  - Lambda Exec Engine |                         |
|            |                    +-----------------------+                         |
|            |                                |                                     |
|            |                    | Writes Records                      |
|            |                    v                                     |
|            |                    +-----------------------+                         |
|            |                    | DynamoDB Container    | (External Container     |
|            +------------------> | (Port 8000 / 4566)    |  with Persistent        |
|                                 +-----------------------+  Volume Storage)        |
+-----------------------------------------------------------------------------------+

---

## Repository Structure

kafka-dynamodb-pipeline/
├── proto/                      # Protocol Buffer definitions

├── scripts/                    # Utility, producer, and code generation scripts
│   └── producer.py
├── src/ 
|   └──kafka_dynamodb_pipeline/    # Main application package namespace
│      ├── __init__.py
│      ├── main.py                 # Application Entry Point & AWS Lambda Handler
│      ├── config/                 # Pydantic Settings & Environment Management
│      │   ├── __init__.py
│      │   └── settings.py
│      ├── models/                 # Pydantic Domain Models & Mappers
│      │   ├── __init__.py
│      │   ├── customer_event.py
│      │   └── processing_result.py
│      ├── proto/                  # Generated Protobuf Python Stubs
│      │   ├── __init__.py
│      |.  ├── customer_event.proto
│      │   ├── customer_event_pb2.py
│      │   └── customer_event_pb2.pyi
│      └── utils/                  # Structlog Configuration & Common Helpers
│          ├── __init__.py
│          └── logging.py
├── tests/                      # Unit and Integration Test Suites
│   ├── __init__.py
│   ├── conftest.py
│   ├── test_consumer.py
│   └── test_models.py
├── tofu/                       # OpenTofu / Terraform Infrastructure Specs
│   ├── main.tf
│   ├── outputs.tf
│   └── variables.tf
├── Dockerfile                  # Production AWS Lambda Container Image
├── docker-compose.yml          # Local infrastructure stack (Kafka, DynamoDB, LocalStack)
└── pyproject.toml              # Build backend configuration & dependency specifications

---

## Quick Start

### 1. Prerequisites
- Python: 3.11+
- Docker & Docker Compose
- OpenTofu / Terraform (for infrastructure provisioning)
- Protocol Buffers Compiler (`protoc`)
- `kcat` / `kafkacat` (optional, for raw topic inspection)

### 2. Local Environment Setup

# Clone the repository and navigate to root
```cd kafka-dynamodb-pipeline```

# Create and activate virtual environment
```
python3.11 -m venv .venv
source .venv/bin/activate
```

# Install application and dev dependencies
```pip install -e ".[dev]"```

# Copy default environment settings
```cp .env.example .env```

---

## Dependency Management & Build Tooling

To inspect the current dependency tree:
$ pipdeptree

To update dependencies after modifying pyproject.toml:
```pip install -e ".[dev]"```

---

## Code Generation (Protobuf)

Compile `.proto` schema files into Python classes (`_pb2.py`) and type hint interfaces (`_pb2.pyi`):

```
protoc -I=kafka_dynamodb_pipeline/proto --python_out=kafka_dynamodb_pipeline/proto --pyi_out=kafka_dynamodb_pipeline/proto customer_event.proto
```
---

## Environment Variables

Configuration is loaded hierarchically using `pydantic-settings` from environment variables and `.env` files.

| Variable | Default | Description |
|----------|---------|-------------|
| `LOG_LEVEL` | `INFO` | Application log level (`DEBUG`, `INFO`, `WARNING`, `ERROR`, `CRITICAL`) |
| `ENVIRONMENT` | `local` | Target execution environment name |
| `KAFKA_BOOTSTRAP_SERVERS` | `kafka:9092` | Comma-separated list of Kafka broker addresses |
| `KAFKA_TOPICS` | `["customer-events"]` | List or comma-separated string of Kafka topics to consume |
| `DYNAMODB_TABLE_NAME` | `customers` | Target AWS DynamoDB table name |
| `DYNAMODB_REGION_NAME` | `us-east-1` | AWS Region for DynamoDB client connection |
| `DYNAMODB_ENDPOINT_URL` | `http://dynamodb-local:8000` | Custom endpoint for standalone DynamoDB container (leave blank in AWS) |

---

## Infrastructure & Local Deployment

### 1. Start Local Infrastructure

Spin up Kafka, standalone DynamoDB Local (with persistent storage), and LocalStack:

$ docker-compose up -d

### 2. Provision AWS Resources via OpenTofu

Deploy the DynamoDB table, IAM execution roles, Lambda function, and Kafka Event Source Mapping into LocalStack:
```
$ cd tofu
$ tofu init
$ tofu apply -auto-approve \
    -var="dynamodb_endpoint=http://dynamodb-local:8000" \
    -var="kafka_bootstrap_servers=kafka:9092"
$ cd ..
```
---

## End-to-End Integration Verification

### 1. Publish a Sample Protobuf Event to Kafka

Execute the test producer script to publish a serialized `CustomerEventMessage` to the local Kafka broker:

$ KAFKA_BOOTSTRAP_SERVERS="localhost:9092" python scripts/producer.py

### 2. Verify LocalStack Event Processing

Inspect LocalStack logs to verify that the Lambda container was invoked by the Kafka event source poller:

$ docker logs localstack | grep -E "kafka-protobuf-customer-consumer|partition.processing_started"

### 3. Verify Persistence in DynamoDB

Query the standalone DynamoDB Local instance to verify item creation:

$ aws --endpoint-url=http://localhost:8000 dynamodb get-item \
    --table-name customers \
    --key '{"customer_id": {"S": "ALFKI"}}'

---

## Testing & Troubleshooting

### Extracting Raw Kafka Payloads for Unit Testing

To extract and hex-dump a raw binary Protobuf message directly from a running Kafka topic for unit test cases:

$ kcat -b localhost:9092 -t customer-events -c 1 -f '%s' | xxd

### Running Test Suites



## Testing & Static Analysis

This project uses `pytest`, `pytest-cov`, `ruff`, and `mypy` to enforce code quality, static typing, and test coverage across unit and integration boundaries.

### Prerequisites

Ensure development dependencies are installed in your active virtual environment:

`pip install -e ".[dev]"`

### Running Test Suites

Execute the full test suite across all modules:

`pytest`

Execute unit tests in isolation (uses `moto` via `conftest.py` to mock AWS DynamoDB):

`pytest tests/test_consumer.py -v`

### Test File Breakdown

- **`tests/conftest.py`**: Shared `pytest` configuration and fixtures. Automatically loaded by `pytest` to set up mock AWS DynamoDB environments via `moto`, mock Kafka event payloads, and environment settings.
- **`tests/test_consumer.py`**: End-to-end testing of the Kafka consumer loop, message parsing, transformer execution, and DynamoDB record writes.
- **`tests/test_models.py`**: Unit tests for Pydantic schema constraints, string trimming/casing sanitization, and settings-driven `field_validator` logic.

### Static Analysis & Type Checking

Run linting checks:

`ruff check .`

Run code formatting checks:

`ruff format . --check`

Run strict static type checking across the codebase:

`mypy .`

### Code Coverage

Execute the test suite and generate terminal coverage metrics:

`coverage run -m pytest`
`coverage report -m`

Or generate coverage directly using `pytest-cov`:

`pytest --cov=. --cov-report=term-missing`

Generate an HTML report for visual inspection in a browser (saved to `htmlcov/index.html`):

`pytest --cov=. --cov-report=html`